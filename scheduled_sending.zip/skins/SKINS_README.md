# Scheduled Sending – Plugin Skins

This plugin ships with Elastic and Larry skins. The following Larry-based variants were auto-generated from your reference pack:

- autumn-larry
- black-larry
- blue-larry
- green-larry
- grey-larry
- pink-larry
- plata-larry
- summer-larry
- teal-larry
- violet-larry

All these skins inherit the plugin’s Larry CSS/templates. They rely on the parent Roundcube skin for colors and typography, so they will match your variant if selected in Roundcube settings.
